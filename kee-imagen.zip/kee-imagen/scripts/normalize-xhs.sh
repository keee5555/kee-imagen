#!/bin/zsh
set -euo pipefail

if [[ $# -ne 2 ]]; then
  print -u2 "usage: normalize-xhs.sh <input-image> <output-png>"
  exit 2
fi

input_path="$1"
output_path="$2"

if [[ ! -f "$input_path" ]]; then
  print -u2 "input not found: $input_path"
  exit 2
fi

width=$(sips -g pixelWidth "$input_path" | awk '/pixelWidth/ {print $2}')
height=$(sips -g pixelHeight "$input_path" | awk '/pixelHeight/ {print $2}')

if [[ -z "$width" || -z "$height" || "$width" -le 0 || "$height" -le 0 ]]; then
  print -u2 "cannot read image dimensions: $input_path"
  exit 2
fi

deviation=$(awk -v w="$width" -v h="$height" 'BEGIN { d=w*4-h*3; if (d<0) d=-d; printf "%.6f", d/(h*3) }')
if awk -v d="$deviation" 'BEGIN { exit !(d > 0.01) }'; then
  print -u2 "ratio deviation ${deviation} exceeds 1%; regenerate as native 3:4 instead of padding or cropping"
  exit 3
fi

tmp_dir=$(mktemp -d)
trap 'rm -rf "$tmp_dir"' EXIT
tmp_image="$tmp_dir/source.png"
cp "$input_path" "$tmp_image"

if (( width * 4 >= height * 3 )); then
  sips --resampleHeight 1440 "$tmp_image" >/dev/null
else
  sips --resampleWidth 1080 "$tmp_image" >/dev/null
fi
sips --cropToHeightWidth 1440 1080 "$tmp_image" --out "$output_path" >/dev/null

out_width=$(sips -g pixelWidth "$output_path" | awk '/pixelWidth/ {print $2}')
out_height=$(sips -g pixelHeight "$output_path" | awk '/pixelHeight/ {print $2}')
if [[ "$out_width" != "1080" || "$out_height" != "1440" ]]; then
  print -u2 "export verification failed: ${out_width}x${out_height}"
  exit 4
fi

print "ok: $output_path (1080x1440)"
