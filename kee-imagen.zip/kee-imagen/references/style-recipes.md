# Kee Imagen 可选配方

只在推荐或使用非 Core 配方时读取。用户选定配方后，将对应“视觉层”完整加入 `prompt-template.md`，有参考图时使用用户提供的风格图、输出锚点和角色图，缺少时按文字配方生成。

## 参考图职责与冲突顺序

非 Core 配方按以下顺序传入参考图，并在提示词中明确职责：

1. `style-source`：控制人物简化、脸部结构、线条、材质、色彩和完成度，不复制原主体、文字或构图。
2. `style-anchor`：校准该配方如何落到主角、辅助角色和中文内容上，不复制示例文章、物件、文字或构图。
3. 角色参考提供用户确认的身份、外形和服装语义。

配方和 IP 视觉冲突时，配方接管渲染。必须在配方内部重画主角的五官、身体和笔触；不要保留 IP 图的动漫大眼、睫毛、贴纸轮廓、黄色背景或头像构图。即使更换文章和构图，生成结果也应一眼属于对应配方，而不是五种相似的 Core 变体。

## 推荐规则

- 始终把 `Core` 作为 A 选项。
- 从下面 5 套中选出与内容最匹配的 B，再选视觉方向明显不同的 C。
- 关系、故事和情绪优先考虑 1、11、12；步骤、方法和知识拆解优先考虑 2、5。
- 同一文章或系列选定后保持一致，不为追求花样频繁换配方。

## 1 纯人类手绘儿童涂色

适合：真实经历、生活故事、亲子隐喻、带笨拙真诚感的内容。

上游校准图由用户提供，可选。

输出锚点由用户提供，可选。

角色采用用户确认的身份、外形与服装，按当前配方重新绘制五官和身体。辅助角色承担输入、反馈或关系动作。

视觉层：

```text
A genuine human-made children's coloring drawing on a slightly wrinkled sheet of real bright white paper, never a polished digital illustration. An ordinary adult first draws chunky, shaky dark-marker outlines with inconsistent pressure, repeated joins, crude simplified anatomy, asymmetrical dot eyes, awkward hands, naive perspective and visibly imperfect spacing. A 5-8 year old then colors with blunt wax crayons: broken strokes, random directions, uneven pressure, rough pigment, obvious white gaps and several clear marks crossing the outlines. Leave roughly 25%-35% of every large colored shape unfilled. Use only a restrained navy, pale blue, warm yellow-orange, skin-crayon and white-paper palette. Prefer one continuous playful paper scene over tidy panels or a precise grid. Keep the core action readable while every shape remains touchingly homemade. Avoid manga eyes, realistic anatomy, perfect icons, polished children's-book rendering, clean vectors, uniform fill, smooth gradients, 3D, elaborate scenery or a digital crayon filter.
```

文字：默认不写长句；需要时最多 1 个短标题或 3 个短词。

必过：真实纸面、点眼笨拙脸、明显露白、压力不均、至少两处越界；遮住角色识别特征后不能看起来像 Core 动漫脸。

## 2 极简黑白线条讲解漫画

适合：AI 概念、方法步骤、前后变化、因果和轻量教程。

上游校准图由用户提供，可选。

输出锚点由用户提供，可选。

角色采用用户确认的身份、外形与服装，按当前配方重新绘制五官和身体。辅助角色承担输入、反馈或关系动作。

视觉层：

```text
A minimalist black-and-white hand-drawn explainer comic on warm off-white paper. Use thin, nearly uniform black or very dark navy pen lines with a slight human wobble. Redraw every face and body as sparse line-comic anatomy; use no anime facial rendering. Characters and objects are simple open outlines with no filled black masses, gray shading or color accents. Split the content into 2-4 lightly uneven rounded panels only when the idea has multiple steps; otherwise use one open scene. Keep abundant empty space and flat two-dimensional staging with no realistic perspective. Each panel may contain one short handwritten Chinese label of 2-6 characters; place longer explanations outside the image. Avoid polished vector geometry, thick comic inking, dense panels, realistic anatomy, gradients, shadows, textures or decorative backgrounds.
```

比例：横版使用横向分镜；竖版使用自上而下分镜，不锁死数字比例。

必过：纯黑白、细线、大量留白、短文字、线条脸而非动漫脸、主角与辅助角色关系清楚。

## 5 小豆人涂鸦信息图

适合：知识拆解、流程步骤、小红书多格图、输入输出关系。

上游校准图由用户提供，可选。

输出锚点由用户提供，可选。

角色采用用户确认的身份、外形与服装，按当前配方重新绘制五官和身体。辅助角色承担输入、反馈或关系动作。

视觉层：

```text
A hand-drawn bean-person doodle explainer on clean off-white paper. Draw the user-defined protagonist as a radically simplified human doodle with tiny dot eyes and loose stick-like limbs; no anime rendering or facial shading. Supporting characters are unmistakable solid dark-navy bean people with two white dot eyes, tiny expressions and thin stick limbs. Reuse the same assistants across 2-4 loose narrative beats. Arrange the beats diagonally, horizontally or vertically according to the content; do not force a polished grid. Draw all other objects as wobbly dark outline-only doodles with white interiors and no shading. Use exactly one yellow-orange accent in each beat, always attached to the key path, approval action, or the key object; never add red, blue, green or skin-tone fills. Use one short handwritten Chinese label per beat and keep generous white space. Avoid dense infographic boxes, polished card grids, realistic rendering, glossy vectors, gradients, shadows, stickers or PPT styling.
```

必过：主角是简化涂鸦主角、小豆人是深蓝实心辅助角色、没有动漫脸和肤色渲染、每段只有一个黄橙重点。

## 11 情绪叙事淡彩速写

适合：成长、焦虑、陪伴、关系变化、真实人物故事和认知转折。

上游校准图由用户提供，可选。

输出锚点由用户提供，可选。

角色采用用户确认的身份、外形与服装，按当前配方重新绘制五官和身体。辅助角色承担输入、反馈或关系动作。

视觉层：

```text
A minimal emotional narrative sketch on bright white watercolor paper with fine visible tooth. Draw with loose deep indigo or navy pen lines: sparse, confident, slightly trembling, sometimes open, with circular searching strokes around wavy hair and rounded forms. Redraw faces with a few searching lines and quiet expressions, never glossy anime eyes. Use no dense hatching or black shadow masses. Keep 60%-70% of the page as clean white negative space. Apply only thin translucent watercolor, mostly leaving clothing and background unpainted. Use exactly one yellow-orange object as the sole warm high-saturation focal point; cheeks may carry a very light blush. Let relationship, distance and body language between 主角 and the supporting character carry the story instead of a rigid process diagram. Add only a few short emotion marks or one optional handwritten Chinese phrase in the open area. Avoid anime faces, photorealism, full watercolor backgrounds, thick paint, multiple warm accents, crowded detail or decorative scenery.
```

必过：深蓝松线、60%-70% 留白、唯一橙黄焦点、速写脸而非动漫脸、人物关系能讲出故事。

## 12 复古动画概念稿

适合：角色 IP、故事型内容、课程人物、短视频锚图和 i2v 前置设定。

上游校准图由用户提供，可选。

输出锚点由用户提供，可选。

角色采用用户确认的身份、外形与服装，按当前配方重新绘制五官和身体。辅助角色承担输入、反馈或关系动作。

视觉层：

```text
An original high-key mid-century hand-painted animation concept illustration made with traditional opaque gouache and colored pencil on white paper, without imitating a named artist or studio. Stage one cinematic, asymmetric moment with depth rather than three infographic columns. Translate every character into simplified angular anatomy, smaller almond-shaped eyes, graphic noses and cheeks, expressive hands, elongated limbs, bold hair silhouettes and visible model-sheet construction marks. Render the user-defined hair silhouette as one large graphic shape. Use broad uneven gouache blocks, dry-brush edges, colored-pencil underdrawing, exploratory strokes, slightly off-register color and unpainted paper. Build faces from pale milky peach with poster-like form shadows instead of realistic volume. Use a restrained cream, pale peach, dusty periwinkle and deep navy palette, with one yellow-orange control or object as the only high-saturation focal point. Use sparse directional brush marks behind the action. Avoid named-studio imitation, chibi proportions, glossy eyes, eyelashes, sticker borders, clean line-art infographics, precise card grids, 3D, vectors, full backgrounds, muddy grading or contemporary anime styling.
```

文字：默认不加文字；若内容必须标注，最多 1-3 个短词。

必过：高调白纸、水粉色块与铅笔底稿、较小杏仁眼、图形化长发、非对称电影式场景、单一黄橙焦点；不能像现代动漫或贴纸信息图。
