# 单图提示词模板

用户要求优先，其次为平台规格、所选配方、角色身份和默认风格。

```text
Generate one standalone {aspect ratio} Chinese explainer illustration.
Selected recipe: {recipe and its full visual rules}.
Core idea: {one point}.
Protagonist: {user-approved identity, silhouette, outfit and core action}.
Supporting characters: {one or two roles and their specific actions}.
Composition: {fresh physical metaphor, objects and information relationship}.
Reference roles: {list only supplied images and each responsibility}.
Style reference controls rendering. Character reference controls identity and outfit.
Series anchor controls consistency, without copying its content or layout.
Chinese handwritten text: {short exact labels, each adding information}.
For AI-related content: {AI, Agent or Skill and its actual action from the source}.
Keep one core structure readable and all text native to the illustration.
Exclude internal chapter IDs, filenames, paths and version metadata.
Do not copy reference content or turn the scene into a logo portrait.
```

编辑时指定修改区域、目的和需保留的构图、文字、比例及配方。系列漂移时强化同一锚点的笔触、脸部简化、背景明度与色彩比例。
